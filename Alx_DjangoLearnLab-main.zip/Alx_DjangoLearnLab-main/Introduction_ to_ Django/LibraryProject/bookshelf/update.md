book.title = "Nineteen Eighty-Four"
book.save()