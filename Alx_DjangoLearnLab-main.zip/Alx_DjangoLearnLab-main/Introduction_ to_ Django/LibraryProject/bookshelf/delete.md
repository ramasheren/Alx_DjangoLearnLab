from bookshelf.models import Book
book.delete()
Book.objects.all()