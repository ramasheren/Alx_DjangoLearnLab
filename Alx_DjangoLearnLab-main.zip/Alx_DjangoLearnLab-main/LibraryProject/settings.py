AUTH_USER_MODEL = 'accounts.CustomUser'
INSTALLED_APPS = [
    ...
    'bookshelf',
]
